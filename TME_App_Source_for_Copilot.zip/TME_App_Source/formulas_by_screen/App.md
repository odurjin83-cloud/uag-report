# App — Power Fx formulas

### `App` . **MinScreenHeight**  _(App)_
```powerfx
320
```

### `App` . **MinScreenWidth**  _(App)_
```powerfx
320
```

### `App` . **OnStart**  _(App)_
```powerfx
Set(varPictureResponse,{picture:""});// ==========================================
// APP.ONSTART
// OFFLINE CACHE SAFE LOAD
// ==========================================


// ==========================================
// 1. OFFLINE ITEMS
// ==========================================

ClearCollect(
    colOfflineItems,
    {
        number: "",
        displayName: "",
        unitOfMeasure: "",
        itemCategory: "",
        inventory: 0,
        unitCost: 0,
        unitPrice: 0
    }
);

Clear(colOfflineItems);

IfError(
    LoadData(
        colOfflineItems,
        "OfflineItems",
        true
    ),
    Notify(
        "Items local cache уншихад алдаа гарлаа.",
        NotificationType.Warning
    )
);

Set(
    varLoadedItemRows,
    CountRows(colOfflineItems)
);


// ==========================================
// 2. ITEM SYNC INFO
// ==========================================

ClearCollect(
    colItemSyncInfo,
    {
        LastSyncDate: ""
    }
);

Clear(colItemSyncInfo);

IfError(
    LoadData(
        colItemSyncInfo,
        "ItemSyncInfo",
        true
    ),
    Notify(
        "Item sync info уншихад алдаа гарлаа.",
        NotificationType.Warning
    )
);

If(
    CountRows(colItemSyncInfo) = 0,
    Collect(
        colItemSyncInfo,
        {
            LastSyncDate: ""
        }
    )
);


// ==========================================
// 3. OFFLINE STOCK
// ==========================================

ClearCollect(
    colOfflineStock,
    {
        itemNo: "",
        locationCode: "",
        quantity: 0
    }
);

Clear(colOfflineStock);

IfError(
    LoadData(
        colOfflineStock,
        "OfflineStock",
        true
    ),
    Notify(
        "Stock local cache уншихад алдаа гарлаа.",
        NotificationType.Warning
    )
);

Set(
    varLoadedStockRows,
    CountRows(colOfflineStock)
);


// ==========================================
// 4. OFFLINE BINS
// ==========================================

ClearCollect(
    colOfflineBins,
    {
        itemNo: "",
        locationCode: "",
        binCode: ""
    }
);

Clear(colOfflineBins);

IfError(
    LoadData(
        colOfflineBins,
        "OfflineBins",
        true
    ),
    Notify(
        "Bin local cache уншихад алдаа гарлаа.",
        NotificationType.Warning
    )
);


// ==========================================
// 5. OFFLINE INVENTORY COUNT
// ==========================================

ClearCollect(
    colOfflineInventory,
    {
        SyncKey: "",
        Title: "",
        ItemNo: "",
        ItemName: "",
        LocationCode: "",
        OpeningBalance: 0,
        CountQty: 0,
        Variance: 0,
        CountDate: Now(),
        Counter: "",
        Archived: false,
        OwnerEmail: "",
        Revision: 0,
        SharePointID: 0,
        SyncError: "",
        Reason: "",
        Comment: "",
        Resolved: false,
        Synced: false
    }
);

Clear(colOfflineInventory);
Set(varCountOwner,Lower(Trim(User().Email)));
Set(varCountCacheKey,"C21" & Substitute(Text(User().EntraObjectId),"-",""));
Set(varCountStorageError,"");Set(varCountSyncBusy,false);Set(varCountSaving,false);Set(varCountCacheReady,false);
Set(varCountDiskSafeV21,false);Set(varCountLoadErrorV21,false);Set(varCountMenuV21,false);Set(varCountCloudOnlyV21,false);
ClearCollect(colCountDiskV21,{Schema:21,Owner:"",Payload:"[]"});Clear(colCountDiskV21);
ClearCollect(colLegacyInventory,colOfflineInventory);
IfError(LoadData(colLegacyInventory,"OfflineInventory",true),Set(varLegacyReadErrorV21,true));
ClearCollect(colPreviousCountV21,colOfflineInventory);
IfError(LoadData(colPreviousCountV21,"InventoryV19_" & Substitute(EncodeUrl(varCountOwner),".","%2E"),true),Set(varPreviousReadErrorV21,true));
If(!IsBlank(varCountOwner) && !IsBlank(User().EntraObjectId),
IfError(
 LoadData(colCountDiskV21,varCountCacheKey,true);
 If(!IsEmpty(colCountDiskV21),
  If(First(colCountDiskV21).Schema<>21 || First(colCountDiskV21).Owner<>varCountOwner,
   Error({Kind:ErrorKind.Validation,Message:"Хадгалалтын эзэмшигч эсвэл хувилбар тохирохгүй байна."}),
   ClearCollect(colOfflineInventory,ForAll(Table(ParseJSON(First(colCountDiskV21).Payload)) As r,{
    SyncKey:Text(r.Value.SyncKey),Title:Text(r.Value.Title),ItemNo:Text(r.Value.ItemNo),ItemName:Text(r.Value.ItemName),
    LocationCode:Text(r.Value.LocationCode),OpeningBalance:Value(r.Value.OpeningBalance),CountQty:Value(r.Value.CountQty),Variance:Value(r.Value.Variance),
    CountDate:DateTimeValue(Text(r.Value.CountDate)),Counter:Text(r.Value.Counter),OwnerEmail:Text(r.Value.OwnerEmail),
    Revision:Value(r.Value.Revision),Archived:Boolean(r.Value.Archived),SharePointID:Value(r.Value.SharePointID),SyncError:Text(r.Value.SyncError),
    Reason:Text(r.Value.Reason),Comment:Text(r.Value.Comment),Resolved:Boolean(r.Value.Resolved),Synced:Boolean(r.Value.Synced)}))));
 Set(varCountDiskSafeV21,true);true,
 Set(varCountLoadErrorV21,true);Set(varCountStorageError,FirstError.Message);false);
If(varCountDiskSafeV21,
 ForAll(Filter(colPreviousCountV21,OwnerEmail=varCountOwner) As old,
  If(IsBlank(LookUp(colOfflineInventory,SyncKey=old.SyncKey)),Collect(colOfflineInventory,old)));
 IfError(If(!varCountDiskSafeV21,Error({Kind:ErrorKind.Validation,Message:"Төхөөрөмжийн эх санг аюулгүй уншаагүй тул дарж бичихгүй."}),
ClearCollect(colCountDiskV21,{Schema:21,Owner:varCountOwner,Payload:JSON(colOfflineInventory,JSONFormat.Compact)});
SaveData(colCountDiskV21,varCountCacheKey)),Set(varCountStorageError,FirstError.Message),Set(varCountCacheReady,true);Set(varCountStorageError,""))));
Clear(colPreviousCountV21);

// ==========================================
// 6. STOCK SYNC VARIABLES
// ==========================================

Set(
    varStockLoading,
    false
);

Set(
    varLoadedStockRows,
    CountRows(colOfflineStock)
);


// ==========================================
// 7. ITEM SNAPSHOT SYNC VARIABLES
// ==========================================

Set(
    varItemLoading,
    false
);

Set(
    varLoadedItemRows,
    CountRows(colOfflineItems)
);


// ==========================================
// 8. TEMP NEW ITEM SNAPSHOT
// ==========================================

ClearCollect(
    colNewItemsSnapshot,
    {
        number: "",
        displayName: "",
        unitOfMeasure: "",
        itemCategory: "",
        inventory: 0,
        unitCost: 0,
        unitPrice: 0
    }
);

Clear(colNewItemsSnapshot);


// ==========================================
// 9. STOCK CHECK VARIABLES
// ==========================================

Set(
    varStockChecking,
    false
);

Set(
    varStockCheckTotal,
    0
);

Set(
    varStockCheckMatched,
    0
);

Set(
    varStockCheckMismatch,
    0
);

Set(
    varStockCheckLocalTotal,
    0
);

Set(
    varStockCheckMasterTotal,
    0
);

Set(
    varStockCheckDiffTotal,
    0
);


// ==========================================
// 10. STOCK MASTER CHECK COLLECTION
// ==========================================

ClearCollect(
    colStockMasterCheck,
    {
        itemNo: "",
        locationCode: "",
        quantity: 0
    }
);

Clear(colStockMasterCheck);


// ==========================================
// 11. STOCK MISMATCH COLLECTION
// ==========================================

ClearCollect(
    colStockMismatch,
    {
        itemNo: "",
        locationCode: "",
        localQty: 0,
        masterQty: 0,
        difference: 0,
        status: ""
    }
);

Clear(colStockMismatch);


// ==========================================
// 12. TEMP NEW STOCK SNAPSHOT
// ==========================================

ClearCollect(
    colNewStockSnapshot,
    {
        itemNo: "",
        locationCode: "",
        quantity: 0
    }
);

Clear(colNewStockSnapshot);


// ==========================================
// 13. GENERAL VARIABLES
// ==========================================

Set(varItem, Blank());
Set(varOpeningBalance, Blank());
Set(varBarcodeText, Blank());
Set(varItemPicture, Blank());
Set(varNewPicture, Blank());
Set(varJustSelected, false);

Set(varLocationCode, Blank());
Set(varLocationName, Blank());
Set(varShowWarehouseList, false);

Set(varExpandedID, Blank());
Set(varReason, "");
Set(varComment, "");

Set(varFilterType, "Бүгд");

Set(varReportFromDate, Today());
Set(varReportToDate, Today());

ClearCollect(colDStockBaseV17,{itemNo:"",locationCode:"",Qty:0,Cost:0,ItemName:"",Uom:""});Clear(colDStockBaseV17);
IfError(LoadData(colDStockBaseV17,"DashboardStockV17",true),Clear(colDStockBaseV17));
Set(varDStockReadyV17,!IsEmpty(colDStockBaseV17));
Set(varDValue,If(IsEmpty(colDStockBaseV17),Blank(),Sum(colDStockBaseV17,Qty*Cost)));
Set(varDMaxMonth,1);Set(varRptIncludeUncounted,false);
If(!Connection.Connected && !varDStockReadyV17,If(!Coalesce(varDStockBuildingV17,false),
Set(varDStockBuildingV17,true);
IfError(
ClearCollect(colDJoinV17,ForAll(colOfflineItems As i,{JoinNo:i.number,JoinKind:0,JoinCost:i.unitCost,JoinName:i.displayName,JoinUom:i.unitOfMeasure,JoinLocation:"",JoinQty:0}));
Collect(colDJoinV17,ForAll(Filter(colOfflineStock,!IsBlank(itemNo) && !IsBlank(locationCode)) As s,{JoinNo:s.itemNo,JoinKind:1,JoinCost:Blank(),JoinName:"",JoinUom:"",JoinLocation:s.locationCode,JoinQty:s.quantity}));
ClearCollect(colDStockBaseV17,Ungroup(ForAll(GroupBy(colDJoinV17,JoinNo,JoinRows) As g,
With({_master:LookUp(g.JoinRows,JoinKind=0)},
{StockRows:ForAll(GroupBy(Filter(g.JoinRows,JoinKind=1),JoinLocation,LocationRows) As l,
{itemNo:g.JoinNo,locationCode:l.JoinLocation,Qty:Sum(l.LocationRows,JoinQty),Cost:_master.JoinCost,ItemName:Coalesce(_master.JoinName,g.JoinNo),Uom:_master.JoinUom})})),StockRows));
Set(varDValue,If(IsEmpty(colDStockBaseV17),Blank(),Sum(colDStockBaseV17,Qty*Cost)));
Set(varDValuationMissing,CountRows(Filter(colDStockBaseV17,IsBlank(Cost))));
Set(varDStockReadyV17,true);Set(varDStockBuiltAtV17,Now());
IfError(SaveData(colDStockBaseV17,"DashboardStockV17"),Set(varDStockCacheErrorV17,true),Set(varDStockCacheErrorV17,false));
Clear(colDJoinV17);true,
Set(varDStockReadyV17,false);Clear(colDJoinV17);false);
Set(varDStockBuildingV17,false)));
Set(varAutoDataChecked,Blank());Set(varHistoryArchive,false);Set(varHistoryTrash,false);Set(varHistoryDeleteConfirm,false);
If(Connection.Connected && !Coalesce(varStartupSyncRunning,false),
Set(varStartupSyncRunning,true);
Concurrent(Set(varAutoItemsError,false);
IfError(
    Set(varAutoItemsResponse,PA_GetItemsSnapshot.Run());
    ClearCollect(colAutoItemsV16,ForAll(Table(ParseJSON(Coalesce(varAutoItemsResponse.itemsjson,"[]"))) As r,{number:Text(r.Value.number),displayName:Text(r.Value.displayName),unitOfMeasure:Text(r.Value.unitOfMeasure),itemCategory:Text(r.Value.itemCategory),inventory:Value(r.Value.inventory),unitCost:Value(r.Value.unitCost),unitPrice:Value(r.Value.unitPrice)}));
    If(IsEmpty(colAutoItemsV16),Set(varAutoItemsError,true),
        IfError(SaveData(colAutoItemsV16,"OfflineItems"),Set(varAutoItemsCacheError,true),Set(varAutoItemsCacheError,false));
        ClearCollect(colOfflineItems,colAutoItemsV16);Set(varAutoItemsUpdated,Now());Clear(colAutoItemsV16);Set(varAutoItemsResponse,Blank()));true,
    Set(varAutoItemsError,true);false),
Set(varAutoStockError,false);
IfError(
    Set(varAutoStockResponse,PA_GetStockFromExcel.Run());
    ClearCollect(colAutoStockV16,ForAll(Table(ParseJSON(Coalesce(varAutoStockResponse.stockjson,"[]"))) As r,{itemNo:Text(r.Value.itemNo),locationCode:Text(r.Value.locationCode),quantity:Value(r.Value.quantity)}));
    If(IsEmpty(colAutoStockV16),Set(varAutoStockError,true),
        IfError(SaveData(colAutoStockV16,"OfflineStock"),Set(varAutoStockCacheError,true),Set(varAutoStockCacheError,false));
        ClearCollect(colOfflineStock,colAutoStockV16);Set(varAutoStockUpdated,Now());Clear(colAutoStockV16);Set(varAutoStockResponse,Blank()));true,
    Set(varAutoStockError,true);false),
Set(varAutoBinsError,false);
IfError(
    Set(varAutoBinsResponse,PA_GetAllBinsOffline.Run());
    ClearCollect(colAutoBinsV16,ForAll(Table(ParseJSON(Coalesce(varAutoBinsResponse.binsjson,"[]"))) As r,{itemNo:Text(r.Value.itemNo),locationCode:Text(r.Value.locationCode),binCode:Text(r.Value.binCode)}));
    If(IsEmpty(colAutoBinsV16),Set(varAutoBinsError,true),
        IfError(SaveData(colAutoBinsV16,"OfflineBins"),Set(varAutoBinsCacheError,true),Set(varAutoBinsCacheError,false));
        ClearCollect(colOfflineBins,colAutoBinsV16);Set(varAutoBinsUpdated,Now());Clear(colAutoBinsV16);Set(varAutoBinsResponse,Blank()));true,
    Set(varAutoBinsError,true);false),
If(Connection.Connected && !IsBlank(varCountOwner) && !Coalesce(varCountSaving,false) && !Coalesce(varCountSyncBusy,false) && !Coalesce(varHistoryLoading,false),
Set(varHistoryLoading,true);Set(varHistoryCloudError,false);
IfError(
    Refresh(InventoryCount);
    ClearCollect(colRestoreCloudV16,Filter(InventoryCount,Counter=varCountOwner || (Counter=User().FullName && 'Created By'.Email=varCountOwner)));
    Set(varHistoryCloudLimit,CountRows(colRestoreCloudV16)>=5000);
    ClearCollect(colRestoreRowsV16,ForAll(colRestoreCloudV16 As r,With({_title:If(StartsWith(r.Title,"ARCHIVED:"),Mid(r.Title,10),r.Title)},{
        SyncKey:If(StartsWith(_title,"COUNT:"),Mid(_title,7),"SP-" & Text(r.ID)),
        Title:_title,Archived:StartsWith(r.Title,"ARCHIVED:"),ItemNo:r.ItemNo,ItemName:r.ItemName,LocationCode:Trim(r.LocationCode),
        OpeningBalance:IfError(Value(r.OpeningBalance),Blank()),CountQty:IfError(Value(r.CountQty),Blank()),
        Variance:IfError(Value(r.CountQty)-Value(r.OpeningBalance),Blank()),CountDate:IfError(DateTimeValue(r.CountDate),Blank()),
        Counter:Coalesce(r.Counter,User().FullName),OwnerEmail:varCountOwner,SharePointID:r.ID,Revision:0,SyncError:"",
        Reason:r.Reason,Comment:r.Comment,Resolved:r.Resolved,Synced:true})));
    ClearCollect(colHistoryMergeV16,AddColumns(colOfflineInventory,MergePriority,If(Synced,0,2)));
    Collect(colHistoryMergeV16,AddColumns(colRestoreRowsV16,MergePriority,1));
    ClearCollect(colHistoryMergedV16,ForAll(GroupBy(colHistoryMergeV16,SyncKey,MergeRows) As g,
        Patch(First(SortByColumns(g.MergeRows,"MergePriority",SortOrder.Descending)),{SyncKey:g.SyncKey})));
    ClearCollect(colOfflineInventory,DropColumns(colHistoryMergedV16,MergePriority));
    Set(varHistoryRefreshed,Now());Clear(colRestoreCloudV16);Clear(colRestoreRowsV16);Clear(colHistoryMergeV16);Clear(colHistoryMergedV16);
    If(varCountCacheReady,IfError(If(!varCountDiskSafeV21,Error({Kind:ErrorKind.Validation,Message:"Төхөөрөмжийн эх санг аюулгүй уншаагүй тул дарж бичихгүй."}),
ClearCollect(colCountDiskV21,{Schema:21,Owner:varCountOwner,Payload:JSON(colOfflineInventory,JSONFormat.Compact)});
SaveData(colCountDiskV21,varCountCacheKey)),Set(varHistoryCacheError,true),Set(varHistoryCacheError,false)));
    true,
    Set(varHistoryCloudError,true);false);
Set(varHistoryLoading,false)));
Set(varLoadedItemRows,CountRows(colOfflineItems));Set(varLoadedStockRows,CountRows(colOfflineStock));
If(!Coalesce(varDStockBuildingV17,false),
Set(varDStockBuildingV17,true);
IfError(
ClearCollect(colDJoinV17,ForAll(colOfflineItems As i,{JoinNo:i.number,JoinKind:0,JoinCost:i.unitCost,JoinName:i.displayName,JoinUom:i.unitOfMeasure,JoinLocation:"",JoinQty:0}));
Collect(colDJoinV17,ForAll(Filter(colOfflineStock,!IsBlank(itemNo) && !IsBlank(locationCode)) As s,{JoinNo:s.itemNo,JoinKind:1,JoinCost:Blank(),JoinName:"",JoinUom:"",JoinLocation:s.locationCode,JoinQty:s.quantity}));
ClearCollect(colDStockBaseV17,Ungroup(ForAll(GroupBy(colDJoinV17,JoinNo,JoinRows) As g,
With({_master:LookUp(g.JoinRows,JoinKind=0)},
{StockRows:ForAll(GroupBy(Filter(g.JoinRows,JoinKind=1),JoinLocation,LocationRows) As l,
{itemNo:g.JoinNo,locationCode:l.JoinLocation,Qty:Sum(l.LocationRows,JoinQty),Cost:_master.JoinCost,ItemName:Coalesce(_master.JoinName,g.JoinNo),Uom:_master.JoinUom})})),StockRows));
Set(varDValue,If(IsEmpty(colDStockBaseV17),Blank(),Sum(colDStockBaseV17,Qty*Cost)));
Set(varDValuationMissing,CountRows(Filter(colDStockBaseV17,IsBlank(Cost))));
Set(varDStockReadyV17,true);Set(varDStockBuiltAtV17,Now());
IfError(SaveData(colDStockBaseV17,"DashboardStockV17"),Set(varDStockCacheErrorV17,true),Set(varDStockCacheErrorV17,false));
Clear(colDJoinV17);true,
Set(varDStockReadyV17,false);Clear(colDJoinV17);false);
Set(varDStockBuildingV17,false));Set(varAutoDataChecked,Now());Set(varStartupSyncRunning,false);
Set(varCountUploadQueue,!IsEmpty(Filter(colOfflineInventory,OwnerEmail=varCountOwner && !Synced))));
ClearCollect(colHomeLatest,ForAll(GroupBy(Filter(colOfflineInventory,!Coalesce(Archived,false) && OwnerEmail=varCountOwner && !IsBlank(ItemNo)),ItemNo,LocationCode,HomeRows) As g,Patch(First(SortByColumns(g.HomeRows,"CountDate",SortOrder.Descending,"SyncKey",SortOrder.Descending)),{ItemNo:g.ItemNo,LocationCode:g.LocationCode})));
ClearCollect(colHomeMonths,ForAll(Sequence(8) As m,With({d:DateAdd(Date(Year(Today()),Month(Today()),1),m.Value-8,TimeUnit.Months)},{MonthDate:d,Total:CountRows(Filter(colOfflineInventory,!Coalesce(Archived,false) && OwnerEmail=varCountOwner && CountDate>=d && CountDate<DateAdd(d,1,TimeUnit.Months))),Pending:CountRows(Filter(colOfflineInventory,!Coalesce(Archived,false) && OwnerEmail=varCountOwner && !Synced && CountDate>=d && CountDate<DateAdd(d,1,TimeUnit.Months)))})));
Set(varHomeAccuracy,If(IsEmpty(colHomeLatest),Blank(),CountRows(Filter(colHomeLatest,!IsBlank(OpeningBalance) && !IsBlank(CountQty) && CountQty=OpeningBalance))/CountRows(colHomeLatest)*100));
Set(varHomeEstimate,If(IsEmpty(colOfflineItems),Blank(),Sum(colOfflineItems,inventory*unitCost)))
```

### `App` . **StartScreen**  _(App)_
```powerfx
ScrAccess
```

### `App` . **Theme**  _(App)_
```powerfx
PowerAppsTheme
```

